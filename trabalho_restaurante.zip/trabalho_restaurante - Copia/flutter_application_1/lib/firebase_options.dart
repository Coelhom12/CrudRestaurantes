
import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart'
    show defaultTargetPlatform, kIsWeb, TargetPlatform;

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) {
      return web;
    }
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return android;
      case TargetPlatform.iOS:
        return ios;
      case TargetPlatform.macOS:
        throw UnsupportedError(
          'DefaultFirebaseOptions have not been configured for macos - '
          'you can reconfigure this by running the FlutterFire CLI again.',
        );
      case TargetPlatform.windows:
        return windows;
      case TargetPlatform.linux:
        throw UnsupportedError(
          'DefaultFirebaseOptions have not been configured for linux - '
          'you can reconfigure this by running the FlutterFire CLI again.',
        );
      default:
        throw UnsupportedError(
          'DefaultFirebaseOptions are not supported for this platform.',
        );
    }
  }

  static const FirebaseOptions web = FirebaseOptions(
    apiKey: 'AIzaSyAtSt0Jau0NJYhDDwVblYM8rrHQTLN_Rlo',
    appId: '1:259602519170:web:03c10ef3e6e12b222a509b',
    messagingSenderId: '259602519170',
    projectId: 'trabalho-restaurante-7ddfa',
    authDomain: 'trabalho-restaurante-7ddfa.firebaseapp.com',
    databaseURL: 'https://trabalho-restaurante-7ddfa-default-rtdb.firebaseio.com',
    storageBucket: 'trabalho-restaurante-7ddfa.firebasestorage.app',
    measurementId: 'G-YRRD4NB8CT',
  );

  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'AIzaSyAcxnb2FcihQWm1fgjB9OBE9N1n-qtigeY',
    appId: '1:259602519170:android:9c2ddc96414548102a509b',
    messagingSenderId: '259602519170',
    projectId: 'trabalho-restaurante-7ddfa',
    databaseURL: 'https://trabalho-restaurante-7ddfa-default-rtdb.firebaseio.com',
    storageBucket: 'trabalho-restaurante-7ddfa.firebasestorage.app',
  );

  static const FirebaseOptions ios = FirebaseOptions(
    apiKey: 'AIzaSyCMO5pVmwI7wGqFcaoRgV1UE5waaWCozfw',
    appId: '1:259602519170:ios:48eef75ef15c17512a509b',
    messagingSenderId: '259602519170',
    projectId: 'trabalho-restaurante-7ddfa',
    databaseURL: 'https://trabalho-restaurante-7ddfa-default-rtdb.firebaseio.com',
    storageBucket: 'trabalho-restaurante-7ddfa.firebasestorage.app',
    iosBundleId: 'com.example.trabalhoRestaurante',
  );

  static const FirebaseOptions windows = FirebaseOptions(
    apiKey: 'AIzaSyAtSt0Jau0NJYhDDwVblYM8rrHQTLN_Rlo',
    appId: '1:259602519170:web:374f99f726cbbe002a509b',
    messagingSenderId: '259602519170',
    projectId: 'trabalho-restaurante-7ddfa',
    authDomain: 'trabalho-restaurante-7ddfa.firebaseapp.com',
    databaseURL: 'https://trabalho-restaurante-7ddfa-default-rtdb.firebaseio.com',
    storageBucket: 'trabalho-restaurante-7ddfa.firebasestorage.app',
    measurementId: 'G-F0GX6SEDK8',
  );

}