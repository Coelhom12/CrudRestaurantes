class Restaurante {
  String id;
  String nome;
  String descricao;
  String tipoComida;

  Restaurante({
    required this.id,
    required this.nome,
    required this.descricao,
    required this.tipoComida,
  });

  // Função para converter o restaurante em um mapa para o Firebase
  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'nome': nome,
      'descricao': descricao,
      'tipoComida': tipoComida,
    };
  }

  // Função para criar um restaurante a partir de um documento do Firebase
  static Restaurante fromMap(Map<String, dynamic> map, String id) {
    return Restaurante(
      id: id,
      nome: map['nome'],
      descricao: map['descricao'],
      tipoComida: map['tipoComida'],
    );
  }
}
