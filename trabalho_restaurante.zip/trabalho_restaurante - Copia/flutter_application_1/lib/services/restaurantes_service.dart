import 'package:cloud_firestore/cloud_firestore.dart';

void adicionarRestaurante() async {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  try {
    await _firestore.collection('restaurantes').add({
      'nome': 'Restaurante Exemplo',
      'descricao': 'Descrição do restaurante',
      'tipoComida': 'Italiana',
    });
    print('Restaurante adicionado com sucesso!');
  } catch (e) {
    print('Erro ao adicionar restaurante: $e');
  }
}
