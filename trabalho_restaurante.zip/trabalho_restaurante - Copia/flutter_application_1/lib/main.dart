import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'firebase_options.dart';
import 'screens/lista_restaurantes.dart';
import 'screens/adicionar_restaurante.dart';
import 'screens/editar_restaurante.dart'; // Importar a tela de edição

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Gestão de Restaurantes',
      theme: ThemeData(
        primarySwatch: Colors.green,
      ),
      initialRoute: '/',
      routes: {
        '/': (context) => ListaRestaurantes(),
        '/adicionar': (context) => AdicionarRestaurante(),
        '/editar': (context) => EditarRestaurante(), // Rota para a tela de edição
      },
    );
  }
}
