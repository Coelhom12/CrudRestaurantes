import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/restaurante.dart';

class EditarRestaurante extends StatefulWidget {
  @override
  _EditarRestauranteState createState() => _EditarRestauranteState();
}

class _EditarRestauranteState extends State<EditarRestaurante> {
  final _formKey = GlobalKey<FormState>();
  late String _nome;
  late String _descricao;
  late String _tipoComida;

  // Lista de tipos de comida para o dropdown
  final List<String> _tiposDeComida = [
    'Brasileira',
    'Italiana',
    'Japonesa',
    'Mexicana',
    'Chinesa',
    'Indiana',
    'Vegetariana',
    'Outros'
  ];

  @override
  Widget build(BuildContext context) {
    final Restaurante restaurante = ModalRoute.of(context)!.settings.arguments as Restaurante;

    _nome = restaurante.nome;
    _descricao = restaurante.descricao;
    _tipoComida = restaurante.tipoComida;

    return Scaffold(
      appBar: AppBar(
        title: Text('Editar Restaurante'),
        backgroundColor: Color(0xFFdcb483), // Cor do AppBar
      ),
      body: Container(
        color: Color(0xFFF5E5D0), // Fundo da tela para combinar com a tela de lista
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              TextFormField(
                initialValue: _nome,
                decoration: InputDecoration(labelText: 'Nome'),
                onSaved: (value) => _nome = value!,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Por favor, insira um nome';
                  }
                  return null;
                },
              ),
              TextFormField(
                initialValue: _descricao,
                decoration: InputDecoration(labelText: 'Descrição'),
                onSaved: (value) => _descricao = value!,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Por favor, insira uma descrição';
                  }
                  return null;
                },
              ),
              DropdownButtonFormField<String>(
                value: _tipoComida,
                decoration: InputDecoration(labelText: 'Tipo de Comida'),
                items: _tiposDeComida.map((String tipo) {
                  return DropdownMenuItem<String>(
                    value: tipo,
                    child: Text(tipo),
                  );
                }).toList(),
                onChanged: (String? newValue) {
                  setState(() {
                    _tipoComida = newValue!;
                  });
                },
                onSaved: (value) => _tipoComida = value!,
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: () async {
                  if (_formKey.currentState!.validate()) {
                    _formKey.currentState!.save();

                    try {
                      await FirebaseFirestore.instance
                          .collection('restaurantes')
                          .doc(restaurante.id)
                          .update({
                        'nome': _nome,
                        'descricao': _descricao,
                        'tipoComida': _tipoComida,
                      });
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text('Restaurante atualizado com sucesso!')),
                      );
                      Navigator.pop(context);
                    } catch (e) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text('Erro ao atualizar restaurante: $e')),
                      );
                    }
                  }
                },
                child: Text('Salvar Alterações'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Color(0xFFdcb483), // Cor do botão
                ),
              ),
              SizedBox(height: 10),
              ElevatedButton(
                onPressed: () async {
                  bool confirmarExclusao = await showDialog(
                    context: context,
                    builder: (context) => AlertDialog(
                      title: Text('Confirmar Exclusão'),
                      content: Text('Tem certeza de que deseja excluir este restaurante?'),
                      actions: [
                        TextButton(
                          child: Text('Cancelar'),
                          onPressed: () {
                            Navigator.pop(context, false);
                          },
                        ),
                        TextButton(
                          child: Text('Excluir'),
                          onPressed: () {
                            Navigator.pop(context, true);
                          },
                        ),
                      ],
                    ),
                  );

                  if (confirmarExclusao) {
                    try {
                      await FirebaseFirestore.instance
                          .collection('restaurantes')
                          .doc(restaurante.id)
                          .delete();
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text('Restaurante excluído com sucesso!')),
                      );
                      Navigator.pop(context);
                    } catch (e) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text('Erro ao excluir restaurante: $e')),
                      );
                    }
                  }
                },
                child: Text('Excluir Restaurante'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.red[400], // Cor do botão de exclusão
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
