import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class AdicionarRestaurante extends StatefulWidget {
  @override
  _AdicionarRestauranteState createState() => _AdicionarRestauranteState();
}

class _AdicionarRestauranteState extends State<AdicionarRestaurante> {
  final _formKey = GlobalKey<FormState>();
  String _nome = '';
  String _descricao = '';
  String _tipoComida = 'Brasileira'; // Tipo de comida padrão

  // Lista de tipos de comida fixos
  final List<String> tiposComida = [
    'Brasileira',
    'Italiana',
    'Japonesa',
    'Mexicana',
    'Chinesa',
    'Indiana',
    'Árabe',
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Adicionar Restaurante'),
        backgroundColor: Color(0xFFdcb483), // Cor do AppBar
      ),
      body: Form(
        key: _formKey,
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            children: [
              TextFormField(
                decoration: InputDecoration(labelText: 'Nome'),
                onSaved: (value) => _nome = value!,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Por favor, insira um nome';
                  }
                  return null;
                },
              ),
              TextFormField(
                decoration: InputDecoration(labelText: 'Descrição'),
                onSaved: (value) => _descricao = value!,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Por favor, insira uma descrição';
                  }
                  return null;
                },
              ),
              DropdownButtonFormField<String>(
                decoration: InputDecoration(labelText: 'Tipo de Comida'),
                value: _tipoComida,
                items: tiposComida.map((String tipo) {
                  return DropdownMenuItem<String>(
                    value: tipo,
                    child: Text(tipo),
                  );
                }).toList(),
                onChanged: (value) {
                  setState(() {
                    _tipoComida = value!;
                  });
                },
                onSaved: (value) => _tipoComida = value!,
              ),
              SizedBox(height: 20),
              ElevatedButton(
                child: Text('Salvar'),
                onPressed: () {
                  if (_formKey.currentState!.validate()) {
                    _formKey.currentState!.save();
                    FirebaseFirestore.instance.collection('restaurantes').add({
                      'nome': _nome,
                      'descricao': _descricao,
                      'tipoComida': _tipoComida,
                    });
                    Navigator.pop(context);
                  }
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Color(0xFFdcb483), // Cor de fundo do botão
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
